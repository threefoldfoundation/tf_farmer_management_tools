ansible-galaxy collection install community.general
export CRYPTOGRAPHY_DONT_BUILD_RUST=1
pip3 install --upgrade pip
pip3 install -r requirements.txt --user
