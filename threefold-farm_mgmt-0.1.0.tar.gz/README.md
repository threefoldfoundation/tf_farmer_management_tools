# tf_farmer_management_tools

This repo is the main place for ThreeFold farmers to educate themselves on how to setup professional datacenter based ThreeFold farms. It also contains tools which can be used by farmers to setup and maintain their farms.
